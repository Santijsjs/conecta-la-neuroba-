/* =========================================================================
   CONECTA LA NEURONA — Lógica del juego
   -------------------------------------------------------------------------
   Juego educativo sobre el sistema nervioso para estudiantes de nivel
   medio superior (Ciencias de la Salud I).

   Contenido del archivo:
     1. Estado del juego y constantes
     2. Utilidades (HUD, avisos, sonido)
     3. Arrastrar y soltar con Pointer Events (funciona en mouse y táctil)
     4. Nivel 1 — Construye la neurona
     5. Nivel 2 — Transmite el impulso
     6. Nivel 3 — Conecta dos neuronas (sinapsis)
     7. Nivel 4 — Del cerebro al músculo
     8. Preguntas educativas (quizzes)
     9. Vidas, fin de juego y pantalla de victoria
   ========================================================================= */

(function () {
  'use strict';

  /* =====================================================================
     1. ESTADO DEL JUEGO Y CONSTANTES
     ===================================================================== */

  const PUNTOS_CONEXION = 100;      // conexión o respuesta correcta
  const PUNTOS_ERROR = -25;         // respuesta o colocación incorrecta
  const PUNTOS_NIVEL = 500;         // completar un nivel
  const BONIFICACION_FINAL = 1000;  // completar el juego
  const VIDAS_INICIALES = 3;
  const TOTAL_PASOS = 7;            // 4 niveles + 3 bloques de preguntas

  let estado = {};

  function estadoInicial() {
    return {
      puntos: 0,
      vidas: VIDAS_INICIALES,
      nivel: 1,
      sonido: true,
      aciertos: 0,
      errores: 0,
      progreso: 0,          // pasos completados (para la barra superior)
      partesColocadas: 0,   // solo nivel 1
      impulsoLanzado: false,
      ordenActual: 0        // solo nivel 4
    };
  }

  /* Información educativa de cada estructura de la neurona.
     Se usa en el nivel 1 y en las explicaciones. */
  const PARTES = {
    dendritas: {
      nombre: 'Dendritas',
      explicacion: 'Dendritas: reciben las señales (neurotransmisores) que llegan de otras células nerviosas. Son las "antenas" de la neurona.'
    },
    soma: {
      nombre: 'Cuerpo celular (soma)',
      explicacion: 'Cuerpo celular o soma: contiene el núcleo y los organelos. Integra la información que llega por las dendritas y mantiene viva a la neurona.'
    },
    axon: {
      nombre: 'Axón',
      explicacion: 'Axón: prolongación larga y delgada que conduce el impulso nervioso desde el soma hasta las terminales axónicas.'
    },
    mielina: {
      nombre: 'Vaina de mielina',
      explicacion: 'Vaina de mielina: capa de lípidos que envuelve y aísla el axón. Hace que el impulso viaje más rápido (conducción saltatoria), saltando de un nódulo a otro.'
    },
    terminales: {
      nombre: 'Terminales axónicas',
      explicacion: 'Terminales axónicas: extremos del axón que liberan neurotransmisores al espacio sináptico para comunicarse con la siguiente neurona o con un músculo.'
    }
  };

  /* Orden anatómico del impulso nervioso */
  const ORDEN_NEURONA = ['dendritas', 'soma', 'axon', 'mielina', 'terminales'];

  /* Estructuras del nivel 4 en el orden fisiológico correcto */
  const RECORRIDO = [
    { id: 'cerebro', nombre: 'Cerebro', etiqueta: 'et-n4-cerebro', detalle: 'El cerebro interpreta la información y decide la orden de movimiento.' },
    { id: 'medula', nombre: 'Médula espinal', etiqueta: 'et-n4-medula', detalle: 'La médula espinal es la vía por la que baja la orden desde el cerebro.' },
    { id: 'nervio', nombre: 'Nervio', etiqueta: 'et-n4-nervio', detalle: 'El nervio transporta la señal hasta la zona del cuerpo que debe moverse.' },
    { id: 'musculo', nombre: 'Músculo', etiqueta: 'et-n4-musculo', detalle: 'El músculo recibe la señal y responde contrayéndose: ¡ya hay movimiento!' }
  ];

  /* =====================================================================
     2. UTILIDADES: referencias, HUD, avisos y sonido
     ===================================================================== */

  const $ = (id) => document.getElementById(id);

  function mostrarPantalla(id) {
    document.querySelectorAll('.pantalla').forEach((p) => p.classList.remove('activa'));
    const pantalla = $(id);
    if (pantalla) pantalla.classList.add('activa');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function actualizarHUD(animarPuntos) {
    $('hud-nivel').textContent = estado.nivel + '/4';
    $('hud-puntos').textContent = estado.puntos;
    $('hud-vidas').textContent = estado.vidas > 0 ? '❤️'.repeat(estado.vidas) : '💔';
    $('barra-relleno').style.width = Math.min(100, (estado.progreso / TOTAL_PASOS) * 100) + '%';

    if (animarPuntos) {
      const el = $('hud-puntos');
      el.classList.remove('pulso');
      void el.offsetWidth; // fuerza el reinicio de la animación
      el.classList.add('pulso');
    }
  }

  /* Suma o resta puntos. Los puntos nunca quedan en negativo. */
  function sumarPuntos(valor) {
    estado.puntos = Math.max(0, estado.puntos + valor);
    actualizarHUD(valor > 0);
  }

  /* Aviso flotante breve (toast) */
  let temporizadorToast = null;
  function aviso(texto, tipo) {
    const toast = $('toast');
    $('toast-texto').innerHTML = texto;
    toast.className = 'toast visible ' + (tipo || '');
    clearTimeout(temporizadorToast);
    temporizadorToast = setTimeout(() => { toast.className = 'toast'; }, 3600);
  }

  /* ---- Sonido generado con la Web Audio API (sin archivos externos) ---- */
  let ctxAudio = null;
  function obtenerCtx() {
    if (!ctxAudio) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctxAudio = new AC();
    }
    return ctxAudio;
  }

  function tono(frecuencia, duracion, tipo, volumen) {
    if (!estado.sonido) return;
    try {
      const ctx = obtenerCtx();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gan = ctx.createGain();
      osc.type = tipo || 'sine';
      osc.frequency.value = frecuencia;
      gan.gain.setValueAtTime(volumen || 0.12, ctx.currentTime);
      gan.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + (duracion || 0.12));
      osc.connect(gan).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + (duracion || 0.12));
    } catch (e) { /* si el navegador bloquea el audio, el juego sigue funcionando */ }
  }

  const sonidoOk = () => { tono(740, 0.09, 'triangle'); setTimeout(() => tono(1100, 0.13, 'triangle'), 80); };
  const sonidoError = () => { tono(190, 0.2, 'sawtooth', 0.1); };
  const sonidoNivel = () => { [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => tono(f, 0.14, 'triangle'), i * 110)); };
  const sonidoClic = () => { tono(420, 0.06, 'square', 0.07); };

  /* =====================================================================
     3. ARRASTRAR Y SOLTAR (Pointer Events: mouse + táctil)
     ===================================================================== */

  let fantasma = null;        // copia visual que sigue al dedo/cursor
  let piezaArrastrada = null; // pieza que se está moviendo
  let piezaSeleccionada = null; // pieza elegida con un toque (modo alternativo)
  let origenArrastre = null;  // coordenadas del inicio del arrastre
  let zonaResaltada = null;

  function crearFantasma(texto, x, y) {
    eliminarFantasma();
    fantasma = document.createElement('div');
    fantasma.id = 'fantasma';
    fantasma.textContent = texto;
    fantasma.style.left = x + 'px';
    fantasma.style.top = y + 'px';
    document.body.appendChild(fantasma);
  }

  function eliminarFantasma() {
    if (fantasma && fantasma.parentNode) fantasma.parentNode.removeChild(fantasma);
    fantasma = null;
  }

  /* Devuelve la zona del SVG que está bajo el puntero */
  function zonaBajoPuntero(x, y) {
    const el = document.elementFromPoint(x, y);
    return el && el.closest ? el.closest('.zona') : null;
  }

  function resaltarZona(zona) {
    if (zonaResaltada && zonaResaltada !== zona) zonaResaltada.classList.remove('sobre');
    zonaResaltada = zona;
    if (zona) zona.classList.add('sobre');
  }

  /* Conecta los eventos de arrastre a una pieza de la bandeja */
  function activarPieza(pieza) {
    pieza.addEventListener('pointerdown', (e) => {
      if (pieza.classList.contains('colocada')) return;
      e.preventDefault();
      piezaArrastrada = pieza;
      origenArrastre = { x: e.clientX, y: e.clientY };
      pieza.classList.add('arrastrando');
      crearFantasma(pieza.dataset.nombre, e.clientX, e.clientY);
      sonidoClic();
    });
  }

  /* Movimiento global mientras se arrastra */
  document.addEventListener('pointermove', (e) => {
    if (!piezaArrastrada) return;
    if (fantasma) {
      fantasma.style.left = e.clientX + 'px';
      fantasma.style.top = e.clientY + 'px';
    }
    resaltarZona(zonaBajoPuntero(e.clientX, e.clientY));
  });

  /* Fin del arrastre */
  document.addEventListener('pointerup', (e) => {
    if (!piezaArrastrada) return;

    const pieza = piezaArrastrada;
    const zona = zonaBajoPuntero(e.clientX, e.clientY);
    const distancia = Math.hypot(e.clientX - origenArrastre.x, e.clientY - origenArrastre.y);

    pieza.classList.remove('arrastrando');
    piezaArrastrada = null;
    eliminarFantasma();
    resaltarZona(null);

    if (zona) {
      intentarColocar(pieza, zona);
    } else if (distancia < 10) {
      // Toque corto: la pieza queda seleccionada y se puede tocar una zona
      if (piezaSeleccionada && piezaSeleccionada !== pieza) piezaSeleccionada.classList.remove('seleccionada');
      piezaSeleccionada = pieza;
      pieza.classList.add('seleccionada');
      aviso('Pieza seleccionada: <strong>' + pieza.dataset.nombre + '</strong>. Ahora toca la zona correcta de la neurona.');
    }
  });

  /* Modo alternativo: tocar una zona con una pieza ya seleccionada */
  function activarZona(zona) {
    zona.addEventListener('pointerdown', () => {
      if (!piezaSeleccionada || piezaArrastrada) return;
      const pieza = piezaSeleccionada;
      piezaSeleccionada = null;
      pieza.classList.remove('seleccionada');
      intentarColocar(pieza, zona);
    });
  }

  /* =====================================================================
     4. NIVEL 1 — CONSTRUYE LA NEURONA
     ===================================================================== */

  const ZONAS_N1 = ['zona-dendritas', 'zona-soma', 'zona-axon', 'zona-mielina', 'zona-terminales'];

  function iniciarNivel1() {
    estado.nivel = 1;
    estado.partesColocadas = 0;
    estado.ordenActual = 0;
    piezaSeleccionada = null;
    actualizarHUD();

    // Ocultar figuras y reiniciar zonas
    ORDEN_NEURONA.forEach((p) => {
      $('fig-' + p).classList.remove('visible');
    });
    ZONAS_N1.forEach((id) => {
      const z = $(id);
      z.classList.remove('ocupada', 'error', 'sobre', 'resaltada');
      if (z.dataset.listo !== '1') {
        z.dataset.listo = '1';
        activarZona(z);
      }
    });
    $('etiqueta-n1').textContent = '';
    $('banner-n1').classList.add('oculto');

    // Crear las piezas desordenadas
    const bandeja = $('nivel1-tray');
    bandeja.innerHTML = '';
    const orden = ORDEN_NEURONA.slice().sort(() => Math.random() - 0.5);
    orden.forEach((clave) => {
      const pieza = document.createElement('div');
      pieza.className = 'pieza';
      pieza.textContent = PARTES[clave].nombre;
      pieza.dataset.parte = clave;
      pieza.dataset.nombre = PARTES[clave].nombre;
      activarPieza(pieza);
      bandeja.appendChild(pieza);
    });

    aviso('Arrastra cada estructura a su lugar. También puedes tocar una pieza y luego tocar su zona.', '');
    mostrarPantalla('pantalla-nivel1');
  }

  /* Intenta colocar una pieza en una zona del nivel 1 */
  function intentarColocar(pieza, zona) {
    if (zona.classList.contains('ocupada')) return;

    if (zona.dataset.parte === pieza.dataset.parte) {
      /* ---- Colocación correcta ---- */
      zona.classList.add('ocupada');
      $('fig-' + pieza.dataset.parte).classList.add('visible');
      pieza.classList.add('colocada');
      pieza.classList.remove('seleccionada');
      piezaSeleccionada = null;
      estado.partesColocadas++;
      estado.aciertos++;
      sumarPuntos(PUNTOS_CONEXION);
      sonidoOk();
      aviso('✅ ' + PARTES[pieza.dataset.parte].explicacion, 'ok');
      $('etiqueta-n1').textContent = '+100 puntos — ' + PARTES[pieza.dataset.parte].nombre;

      if (estado.partesColocadas === ORDEN_NEURONA.length) {
        completarConstruccion();
      }
    } else {
      /* ---- Colocación incorrecta ---- */
      zona.classList.add('error');
      setTimeout(() => zona.classList.remove('error'), 500);
      estado.errores++;
      sumarPuntos(PUNTOS_ERROR);
      sonidoError();
      perderVida('Esa no es la zona de <strong>' + pieza.dataset.nombre + '</strong>. Revisa la explicación de la pista.');
    }
  }

  function completarConstruccion() {
    estado.progreso = 1;
    sumarPuntos(PUNTOS_NIVEL);
    actualizarHUD();
    sonidoNivel();
    $('banner-n1').classList.remove('oculto');
    aviso('🎉 ¡Neurona completa! Recorrido correcto: dendritas → soma → axón → vaina de mielina → terminales axónicas.', 'ok');
  }

  /* Pista: resalta la zona de la primera pieza que falta */
  function darPista() {
    const piezas = document.querySelectorAll('#nivel1-tray .pieza:not(.colocada)');
    if (!piezas.length) return;
    const clave = piezas[0].dataset.parte;
    const zona = $(ZONAS_N1.find((id) => $(id).dataset.parte === clave));
    if (!zona) return;
    zona.classList.add('resaltada');
    aviso('💡 La estructura <strong>' + PARTES[clave].nombre + '</strong> va en la zona resaltada.');
    setTimeout(() => zona.classList.remove('resaltada'), 2400);
  }

  /* =====================================================================
     5. NIVEL 2 — TRANSMITE EL IMPULSO
     ===================================================================== */

  function iniciarNivel2() {
    estado.nivel = 2;
    estado.impulsoLanzado = false;
    actualizarHUD();
    $('etiqueta-n2').textContent = 'Presiona el botón para iniciar el impulso';
    $('chispa').setAttribute('opacity', '0');
    ['n2-dendritas', 'n2-soma', 'n2-axon', 'n2-mielina', 'n2-terminales'].forEach((id) => $(id).classList.remove('activo'));
    mostrarPantalla('pantalla-nivel2');
  }

  /* Anima la chispa a lo largo de la ruta del impulso nervioso */
  function lanzarImpulso() {
    if (estado.impulsoLanzado) return;
    estado.impulsoLanzado = true;
    $('btn-impulso').disabled = true;

    const ruta = $('ruta-impulso');
    const chispa = $('chispa');
    const largo = ruta.getTotalLength();
    const duracion = 2800; // milisegundos

    // Estructuras que se iluminan según el avance de la señal
    const fases = [
      { desde: 0.00, hasta: 0.22, id: 'n2-dendritas', texto: 'Dendritas: reciben la señal de otra neurona.' },
      { desde: 0.22, hasta: 0.38, id: 'n2-soma', texto: 'Soma: integra la información y genera el impulso.' },
      { desde: 0.38, hasta: 0.72, id: 'n2-axon', texto: 'Axón: conduce el impulso eléctrico.' },
      { desde: 0.55, hasta: 0.78, id: 'n2-mielina', texto: 'Vaina de mielina: acelera el impulso (conducción saltatoria).' },
      { desde: 0.80, hasta: 1.01, id: 'n2-terminales', texto: 'Terminales axónicas: liberan neurotransmisores.' }
    ];
    let faseActual = -1;

    chispa.setAttribute('opacity', '1');
    $('etiqueta-n2').textContent = '⚡ Impulso en movimiento…';
    tono(320, 0.5, 'sawtooth', 0.08);

    const inicio = performance.now();
    function paso(ahora) {
      const t = Math.min(1, (ahora - inicio) / duracion);
      const p = ruta.getPointAtLength(largo * t);
      chispa.setAttribute('cx', p.x);
      chispa.setAttribute('cy', p.y);

      const indice = fases.findIndex((f) => t >= f.desde && t < f.hasta);
      if (indice !== faseActual && indice >= 0) {
        faseActual = indice;
        fases.forEach((f) => $(f.id).classList.remove('activo'));
        $(fases[indice].id).classList.add('activo');
        $('etiqueta-n2').textContent = fases[indice].texto;
        aviso('⚡ ' + fases[indice].texto);
        tono(520 + indice * 90, 0.08, 'square', 0.06);
      }

      if (t < 1) {
        requestAnimationFrame(paso);
      } else {
        chispa.setAttribute('opacity', '0');
        finalizarImpulso();
      }
    }
    requestAnimationFrame(paso);
  }

  function finalizarImpulso() {
    // Recorrido completo: se iluminan las cinco estructuras
    ['n2-dendritas', 'n2-soma', 'n2-axon', 'n2-mielina', 'n2-terminales'].forEach((id) => $(id).classList.add('activo'));
    $('etiqueta-n2').textContent = '¡Impulso transmitido correctamente!';
    estado.aciertos++;
    sumarPuntos(PUNTOS_CONEXION);
    sonidoNivel();
    aviso('🎉 ¡Impulso transmitido correctamente! La señal recorrió: dendritas → soma → axón → vaina de mielina → terminales axónicas.', 'ok');
    $('btn-impulso').disabled = false;
    $('btn-impulso').textContent = '⚡ REPETIR EL IMPULSO';

    setTimeout(() => {
      estado.progreso = 3; // nivel 2 completado + preguntas
      sumarPuntos(PUNTOS_NIVEL);
      actualizarHUD();
      iniciarPreguntas('n2', iniciarNivel3);
    }, 1600);
  }

  /* =====================================================================
     6. NIVEL 3 — CONECTA DOS NEURONAS (SINAPSIS)
     ===================================================================== */

  let puertoOrigenSeleccionado = null;
  let arrastrandoConexion = false;

  function iniciarNivel3() {
    estado.nivel = 3;
    actualizarHUD();
    $('linea-conexion').setAttribute('d', '');
    $('linea-conexion').style.opacity = '0';
    $('neurotransmisores').setAttribute('opacity', '0');
    $('neurotransmisores').innerHTML = '';
    $('chispa-n3').setAttribute('opacity', '0');
    puertoOrigenSeleccionado = null;

    document.querySelectorAll('#svg-nivel3 .puerto').forEach((p) => p.classList.remove('seleccionado', 'ok', 'malo'));
    document.querySelectorAll('.foco-neurona').forEach((g) => g.classList.remove('foco-neurona'));

    $('etiqueta-n3').textContent = 'Arrastra del puerto amarillo (terminales axónicas) al puerto correcto de la neurona 2';
    mostrarPantalla('pantalla-nivel3');
  }

  /* Convierte coordenadas de pantalla a coordenadas del SVG */
  function coordsSVG(svg, clientX, clientY) {
    const r = svg.getBoundingClientRect();
    const vb = svg.viewBox.baseVal;
    const escala = Math.min(r.width / vb.width, r.height / vb.height);
    const offsetX = (r.width - vb.width * escala) / 2;
    const offsetY = (r.height - vb.height * escala) / 2;
    return {
      x: (clientX - r.left - offsetX) / escala,
      y: (clientY - r.top - offsetY) / escala
    };
  }

  function configurarConexionNivel3() {
    const svg = $('svg-nivel3');
    const puertoA = $('puerto-a');

    // Inicio del arrastre de la conexión
    puertoA.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      puertoOrigenSeleccionado = puertoA;
      arrastrandoConexion = true;
      puertoA.classList.add('seleccionado');
      const p = coordsSVG(svg, e.clientX, e.clientY);
      $('linea-conexion').setAttribute('d', 'M378 215 L' + p.x + ' ' + p.y);
      $('linea-conexion').style.opacity = '1';
      tono(600, 0.07, 'square', 0.07);
    });

    // La línea sigue al puntero
    document.addEventListener('pointermove', (e) => {
      if (!arrastrandoConexion || !puertoOrigenSeleccionado) return;
      const p = coordsSVG(svg, e.clientX, e.clientY);
      $('linea-conexion').setAttribute('d', 'M378 215 L' + p.x + ' ' + p.y);
    });

    // Al soltar se evalúa el puerto destino
    document.addEventListener('pointerup', (e) => {
      if (!arrastrandoConexion || !puertoOrigenSeleccionado) return;
      arrastrandoConexion = false;

      const el = document.elementFromPoint(e.clientX, e.clientY);
      const puerto = el && el.closest ? el.closest('.puerto') : null;

      if (puerto && puerto !== puertoA) {
        $('linea-conexion').style.opacity = '0';
        evaluarConexion(puerto);
      } else {
        // Si no se soltó sobre un puerto, se mantiene el origen seleccionado
        $('linea-conexion').style.opacity = '0';
        $('etiqueta-n3').textContent = 'Terminales seleccionadas: ahora toca el puerto donde la señal debe continuar';
      }
    });

    // Permite también tocar el puerto destino en lugar de arrastrar
    document.querySelectorAll('#svg-nivel3 .puerto').forEach((puerto) => {
      if (puerto === puertoA) return;
      puerto.addEventListener('pointerdown', (e) => {
        if (!puertoOrigenSeleccionado) {
          aviso('Primero toca el puerto amarillo de las <strong>terminales axónicas</strong> de la neurona 1.');
          return;
        }
        e.preventDefault();
        evaluarConexion(puerto);
      });
    });
  }

  function evaluarConexion(puerto) {
    const puertoA = $('puerto-a');

    if (puerto.dataset.rol === 'dendritas') {
      /* ---- Conexión correcta: sinapsis ---- */
      puerto.classList.add('ok');
      puertoA.classList.add('ok');
      estado.aciertos++;
      sumarPuntos(PUNTOS_CONEXION);
      sonidoOk();
      $('etiqueta-n3').textContent = '¡Sinapsis establecida! La señal pasa a las dendritas de la neurona 2.';
      aviso('✅ Correcto: las terminales axónicas de la neurona 1 liberan neurotransmisores que cruzan el <strong>espacio sináptico</strong> y llegan a las <strong>dendritas</strong> de la neurona 2.', 'ok');
      puertoOrigenSeleccionado = null;

      animarNeurotransmisores(() => {
        animarImpulsoNeurona2();
      });
    } else {
      /* ---- Conexión incorrecta ---- */
      puerto.classList.add('malo');
      setTimeout(() => puerto.classList.remove('malo'), 700);
      estado.errores++;
      sumarPuntos(PUNTOS_ERROR);
      sonidoError();
      $('etiqueta-n3').textContent = 'Conexión incorrecta. Vuelve a intentarlo.';
      perderVida('La señal no puede entrar por el <strong>' + (puerto.dataset.rol === 'axon' ? 'axón' : 'soma') +
        '</strong> de otra neurona: llega primero a las <strong>dendritas</strong>, que son las que reciben los neurotransmisores.');
    }
  }

  /* Dibuja neurotransmisores cruzando el espacio sináptico */
  function animarNeurotransmisores(alTerminar) {
    const grupo = $('neurotransmisores');
    grupo.innerHTML = '';
    grupo.setAttribute('opacity', '1');
    const particulas = [];
    for (let i = 0; i < 9; i++) {
      const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      c.setAttribute('r', 5);
      c.setAttribute('fill', i % 2 ? '#facc15' : '#f472b6');
      c.setAttribute('filter', 'url(#resplandor)');
      c.setAttribute('cx', 386);
      c.setAttribute('cy', 215 + (i - 4) * 11);
      grupo.appendChild(c);
      particulas.push({ el: c, retraso: i * 70, x: 386, y: 215 + (i - 4) * 11, fin: 434 });
    }

    const inicio = performance.now();
    const duracion = 1100;
    function paso(ahora) {
      let activas = 0;
      particulas.forEach((p) => {
        const t = (ahora - inicio - p.retraso) / duracion;
        if (t < 0) { activas++; p.el.setAttribute('opacity', '0'); return; }
        if (t >= 1) { p.el.setAttribute('opacity', '0'); return; }
        activas++;
        p.el.setAttribute('opacity', '1');
        p.el.setAttribute('cx', p.x + (p.fin - p.x) * t);
        p.el.setAttribute('cy', p.y + Math.sin(t * Math.PI) * (t < 0.5 ? -6 : 6));
      });
      if (activas > 0) {
        requestAnimationFrame(paso);
      } else {
        grupo.setAttribute('opacity', '0');
        if (alTerminar) alTerminar();
      }
    }
    requestAnimationFrame(paso);
  }

  /* La señal recorre la segunda neurona y termina el nivel */
  function animarImpulsoNeurona2() {
    const ruta = $('ruta-n3b');
    const chispa = $('chispa-n3');
    const largo = ruta.getTotalLength();
    const duracion = 2000;
    const inicio = performance.now();
    chispa.setAttribute('opacity', '1');

    function paso(ahora) {
      const t = Math.min(1, (ahora - inicio) / duracion);
      const p = ruta.getPointAtLength(largo * t);
      chispa.setAttribute('cx', p.x);
      chispa.setAttribute('cy', p.y);
      if (t < 1) {
        requestAnimationFrame(paso);
      } else {
        chispa.setAttribute('opacity', '0');
        $('etiqueta-n3').textContent = '¡Comunicación entre neuronas completada!';
        aviso('🎉 ¡Las dos neuronas se comunicaron! La sinapsis es el punto donde una neurona "habla" con la siguiente.', 'ok');
        estado.progreso = 5;
        sumarPuntos(PUNTOS_NIVEL);
        actualizarHUD();
        sonidoNivel();
        setTimeout(() => iniciarPreguntas('n3', iniciarNivel4), 1400);
      }
    }
    requestAnimationFrame(paso);
  }

  /* =====================================================================
     7. NIVEL 4 — DEL CEREBRO AL MÚSCULO
     ===================================================================== */

  function iniciarNivel4() {
    estado.nivel = 4;
    estado.ordenActual = 0;
    actualizarHUD();
    $('ruta-n4').setAttribute('opacity', '0');
    $('chispa-n4').setAttribute('opacity', '0');
    ['n4-cerebro', 'n4-medula', 'n4-nervio', 'n4-musculo'].forEach((id) => $(id).classList.remove('activo', 'contraido'));
    ['et-n4-cerebro', 'et-n4-medula', 'et-n4-nervio', 'et-n4-musculo'].forEach((id) => $(id).setAttribute('opacity', '0'));
    $('etiqueta-n4').textContent = 'Ordena el recorrido: ¿qué estructura va primero?';

    const contenedor = $('nivel4-opciones');
    contenedor.innerHTML = '';
    RECORRIDO.slice().sort(() => Math.random() - 0.5).forEach((item) => {
      const boton = document.createElement('button');
      boton.className = 'pieza';
      boton.textContent = item.nombre;
      boton.dataset.id = item.id;
      boton.addEventListener('click', () => elegirEstructura(item.id));
      contenedor.appendChild(boton);
    });

    mostrarPantalla('pantalla-nivel4');
  }

  function elegirEstructura(id) {
    const esperado = RECORRIDO[estado.ordenActual];

    if (id === esperado.id) {
      /* ---- Estructura correcta ---- */
      estado.ordenActual++;
      estado.aciertos++;
      sumarPuntos(PUNTOS_CONEXION);
      sonidoOk();
      $(esperado.etiqueta).setAttribute('opacity', '1');
      $('n4-' + esperado.id).classList.add('activo');
      const boton = document.querySelector('#nivel4-opciones .pieza[data-id="' + id + '"]');
      if (boton) boton.classList.add('colocada');
      aviso('✅ ' + esperado.detalle, 'ok');

      // Marca el número de orden en la etiqueta
      $(esperado.etiqueta).textContent = estado.ordenActual + '. ' + esperado.nombre;
      $('etiqueta-n4').textContent = estado.ordenActual < 4
        ? '¡Bien! ¿Qué estructura sigue en el recorrido?'
        : '¡Recorrido ordenado correctamente!';

      if (estado.ordenActual === RECORRIDO.length) {
        animarRecorridoFinal();
      }
    } else {
      /* ---- Estructura incorrecta ---- */
      estado.errores++;
      sumarPuntos(PUNTOS_ERROR);
      sonidoError();
      aviso('❌ Orden incorrecto. Recuerda: primero el cerebro (que decide), luego la médula espinal, después el nervio y al final el músculo.');
      perderVida('Revisa el orden: <strong>cerebro → médula espinal → nervio → músculo</strong>.');
    }
  }

  function animarRecorridoFinal() {
    const ruta = $('ruta-n4');
    const chispa = $('chispa-n4');
    ruta.setAttribute('opacity', '1');
    chispa.setAttribute('opacity', '1');
    const largo = ruta.getTotalLength();
    const duracion = 2400;
    const inicio = performance.now();

    function paso(ahora) {
      const t = Math.min(1, (ahora - inicio) / duracion);
      const p = ruta.getPointAtLength(largo * t);
      chispa.setAttribute('cx', p.x);
      chispa.setAttribute('cy', p.y);
      if (t < 1) {
        requestAnimationFrame(paso);
      } else {
        chispa.setAttribute('opacity', '0');
        $('n4-musculo').classList.add('contraido');
        sonidoNivel();
        aviso('🎉 ¡Excelente! Completaste el recorrido de una señal nerviosa.', 'ok');
        setTimeout(finalizarJuego, 1900);
      }
    }
    requestAnimationFrame(paso);
  }

  /* =====================================================================
     8. PREGUNTAS EDUCATIVAS
     ===================================================================== */

  const PREGUNTAS = {
    n1: [
      {
        pregunta: '¿Qué estructura recibe las señales de otras neuronas?',
        opciones: ['Axón', 'Dendritas', 'Soma', 'Mielina'],
        correcta: 1,
        explicacion: 'Las dendritas son las prolongaciones cortas y ramificadas que reciben los neurotransmisores enviados por otras neuronas.'
      },
      {
        pregunta: '¿Qué función tiene la vaina de mielina?',
        opciones: [
          'Producir neurotransmisores',
          'Guardar el material genético',
          'Aislar el axón y acelerar el impulso nervioso',
          'Recibir los estímulos del ambiente'
        ],
        correcta: 2,
        explicacion: 'La mielina es una capa grasa que aísla el axón; el impulso "salta" entre los nódulos de Ranvier y así viaja mucho más rápido.'
      }
    ],
    n2: [
      {
        pregunta: '¿Qué es el impulso nervioso?',
        opciones: [
          'Una señal eléctrica que viaja por la membrana de la neurona',
          'Una hormona que libera la sangre',
          'Un músculo que se contrae',
          'Un tipo de hueso del cráneo'
        ],
        correcta: 0,
        explicacion: 'El impulso nervioso es un cambio eléctrico (despolarización) que se desplaza por la membrana de la neurona.'
      },
      {
        pregunta: '¿Cuál es el recorrido correcto del impulso dentro de una neurona?',
        opciones: [
          'Axón → soma → dendritas → terminales',
          'Soma → terminales → axón → dendritas',
          'Dendritas → soma → axón → terminales axónicas',
          'Terminales → dendritas → mielina → soma'
        ],
        correcta: 2,
        explicacion: 'La señal entra por las dendritas, se integra en el soma, viaja por el axón y sale por las terminales axónicas.'
      }
    ],
    n3: [
      {
        pregunta: '¿Qué es la sinapsis?',
        opciones: [
          'El núcleo de la neurona',
          'El punto de comunicación entre dos neuronas',
          'La capa que cubre el axón',
          'Un tipo de músculo involuntario'
        ],
        correcta: 1,
        explicacion: 'En la sinapsis, las terminales axónicas liberan neurotransmisores que cruzan el espacio sináptico y llegan a las dendritas de la siguiente neurona.'
      },
      {
        pregunta: '¿Cómo se comunica una neurona con la siguiente?',
        opciones: [
          'Se tocan directamente sin liberar nada',
          'Liberan neurotransmisores en el espacio sináptico',
          'Intercambian sangre',
          'Se fusionan y forman una sola célula'
        ],
        correcta: 1,
        explicacion: 'La comunicación es química: los neurotransmisores cruzan el espacio sináptico y llevan el mensaje a la neurona siguiente.'
      }
    ]
  };

  let preguntaActual = { lista: [], indice: 0, alTerminar: null, bloqueado: false };

  function iniciarPreguntas(claveNivel, alTerminar) {
    preguntaActual = { lista: PREGUNTAS[claveNivel].slice(), indice: 0, alTerminar: alTerminar, bloqueado: false };
    $('modal-pregunta').classList.add('activo');
    mostrarPregunta();
  }

  function mostrarPregunta() {
    const p = preguntaActual.lista[preguntaActual.indice];
    preguntaActual.bloqueado = false;
    $('pregunta-texto').textContent = p.pregunta;
    $('feedback').classList.add('oculto');
    $('feedback').innerHTML = '';
    $('btn-continuar').classList.add('oculto');

    const contenedor = $('opciones');
    contenedor.innerHTML = '';
    p.opciones.forEach((texto, i) => {
      const boton = document.createElement('button');
      boton.className = 'opcion';
      boton.textContent = String.fromCharCode(65 + i) + ') ' + texto;
      boton.addEventListener('click', () => responderPregunta(i, boton));
      contenedor.appendChild(boton);
    });
  }

  function responderPregunta(indice, boton) {
    if (preguntaActual.bloqueado) return;
    preguntaActual.bloqueado = true;

    const p = preguntaActual.lista[preguntaActual.indice];
    const botones = document.querySelectorAll('#opciones .opcion');
    botones.forEach((b, i) => {
      b.disabled = true;
      if (i === p.correcta) b.classList.add('correcta');
      if (i === indice && indice !== p.correcta) b.classList.add('incorrecta');
    });

    const correcto = indice === p.correcta;
    if (correcto) {
      estado.aciertos++;
      sumarPuntos(PUNTOS_CONEXION);
      sonidoOk();
      $('feedback').innerHTML = '<strong>✅ ¡Correcto! +' + PUNTOS_CONEXION + ' puntos</strong><br>' + p.explicacion;
    } else {
      estado.errores++;
      sumarPuntos(PUNTOS_ERROR);
      sonidoError();
      $('feedback').innerHTML = '<strong>❌ Incorrecto (' + PUNTOS_ERROR + ' puntos)</strong><br>La respuesta correcta es <strong>' +
        String.fromCharCode(65 + p.correcta) + ') ' + p.opciones[p.correcta] + '</strong>.<br>' + p.explicacion;
      perderVida('Observa la explicación de la pregunta: así aprenderás el concepto antes de continuar.', true);
    }

    $('feedback').classList.remove('oculto');
    $('btn-continuar').classList.remove('oculto');
  }

  function continuarPreguntas() {
    preguntaActual.indice++;
    if (preguntaActual.indice < preguntaActual.lista.length) {
      mostrarPregunta();
    } else {
      $('modal-pregunta').classList.remove('activo');
      const alTerminar = preguntaActual.alTerminar;
      if (alTerminar && !estado.gameOver) alTerminar();
    }
  }

  /* =====================================================================
     9. VIDAS, FIN DE JUEGO Y VICTORIA
     ===================================================================== */

  function perderVida(mensaje, silencioso) {
    estado.vidas--;
    actualizarHUD();
    if (!silencioso && mensaje) aviso('💔 ' + mensaje, 'error');
    if (estado.vidas <= 0) {
      estado.gameOver = true;
      setTimeout(() => {
        document.querySelectorAll('.modal').forEach((m) => m.classList.remove('activo'));
        $('modal-gameover').classList.add('activo');
      }, 900);
    }
  }

  function finalizarJuego() {
    estado.progreso = TOTAL_PASOS;
    sumarPuntos(PUNTOS_NIVEL + BONIFICACION_FINAL);
    actualizarHUD();
    $('victoria-puntos').textContent = estado.puntos;
    $('victoria-stats').innerHTML =
      '<div class="stat"><span>Vidas restantes</span><strong>' + '❤️'.repeat(Math.max(0, estado.vidas)) + '</strong></div>' +
      '<div class="stat"><span>Aciertos</span><strong>' + estado.aciertos + '</strong></div>' +
      '<div class="stat"><span>Errores</span><strong>' + estado.errores + '</strong></div>' +
      '<div class="stat"><span>Niveles</span><strong>4/4</strong></div>';
    mostrarPantalla('pantalla-victoria');
    sonidoNivel();
  }

  function reiniciarJuego() {
    estado = estadoInicial();
    estado.gameOver = false;
    document.querySelectorAll('.modal').forEach((m) => m.classList.remove('activo'));
    $('btn-impulso').textContent = '⚡ INICIAR IMPULSO NERVIOSO';
    $('btn-impulso').disabled = false;
    actualizarHUD();
    iniciarNivel1();
  }

  /* =====================================================================
     ARRANQUE: se conectan todos los botones cuando carga la página
     ===================================================================== */

  function iniciarJuego() {
    estado = estadoInicial();
    estado.gameOver = false;
    $('hud').classList.remove('oculto');
    actualizarHUD();
    iniciarNivel1();
  }

  document.addEventListener('DOMContentLoaded', function () {
    estado = estadoInicial();
    actualizarHUD();

    $('btn-jugar').addEventListener('click', iniciarJuego);
    $('btn-aprender').addEventListener('click', () => $('modal-aprender').classList.add('activo'));
    $('btn-cerrar-aprender').addEventListener('click', () => $('modal-aprender').classList.remove('activo'));
    $('btn-pista-n1').addEventListener('click', darPista);
    $('btn-completar-n1').addEventListener('click', () => {
      estado.progreso = 1;
      actualizarHUD();
      iniciarPreguntas('n1', iniciarNivel2);
    });
    $('btn-impulso').addEventListener('click', lanzarImpulso);
    $('btn-sinapsis-info').addEventListener('click', () => {
      aviso('La <strong>sinapsis</strong> es el punto de comunicación entre dos neuronas: las terminales axónicas liberan neurotransmisores que cruzan el espacio sináptico y llegan a las dendritas de la neurona siguiente.');
    });
    $('btn-reiniciar-n4').addEventListener('click', iniciarNivel4);
    $('btn-continuar').addEventListener('click', continuarPreguntas);
    $('btn-rejugar').addEventListener('click', reiniciarJuego);
    $('btn-reintentar').addEventListener('click', reiniciarJuego);
    $('btn-reiniciar').addEventListener('click', () => {
      if (confirm('¿Quieres reiniciar el juego desde el nivel 1?')) reiniciarJuego();
    });
    $('btn-sonido').addEventListener('click', () => {
      estado.sonido = !estado.sonido;
      $('btn-sonido').textContent = estado.sonido ? '🔊' : '🔇';
      if (estado.sonido) sonidoClic();
    });

    configurarConexionNivel3();
  });
})();
